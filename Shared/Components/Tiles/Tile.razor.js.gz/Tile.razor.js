export class Tile {
  
}

window.Tile = Tile;