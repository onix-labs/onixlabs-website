export class Row {
  
}

window.Row = Row;