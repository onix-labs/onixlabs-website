export class Section {
  
}

window.Section = Section;