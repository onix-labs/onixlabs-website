export class Accordion {
  
}

window.Accordion = Accordion;