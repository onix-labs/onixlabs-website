export class AccordionItem {
  
}

window.AccordionItem = AccordionItem;