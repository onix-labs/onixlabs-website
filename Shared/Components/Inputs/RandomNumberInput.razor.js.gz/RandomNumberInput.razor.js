export class RandomNumberInput {
  
}

window.RandomNumberInput = RandomNumberInput;