export class NumberInput {
  
}

window.NumberInput = NumberInput;