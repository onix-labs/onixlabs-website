export class SelectInput {
  
}

window.SelectInput = SelectInput;