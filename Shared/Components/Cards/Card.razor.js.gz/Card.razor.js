export class Card {
  
}

window.Card = Card;