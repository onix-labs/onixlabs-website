export class CardHeader {
  
}

window.CardHeader = CardHeader;