export class CardBody {
  
}

window.CardBody = CardBody;