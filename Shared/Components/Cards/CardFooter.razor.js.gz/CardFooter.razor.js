export class CardFooter {
  
}

window.CardFooter = CardFooter;