export class Icon {
  
}

window.Icon = Icon;