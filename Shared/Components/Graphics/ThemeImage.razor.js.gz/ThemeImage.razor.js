export class ThemeImage {
  
}

window.ThemeImage = ThemeImage;