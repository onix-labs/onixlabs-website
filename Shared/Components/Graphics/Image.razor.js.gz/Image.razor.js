export class Image {
  
}

window.Image = Image;