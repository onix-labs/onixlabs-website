export class Headline {
  
}

window.Headline = Headline;