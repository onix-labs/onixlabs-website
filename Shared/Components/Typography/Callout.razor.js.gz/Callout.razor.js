export class Callout {
  
}

window.Callout = Callout;