export class Paragraph {
  
}

window.Paragraph = Paragraph;