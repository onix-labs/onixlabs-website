export class LayoutHeader {
  
}

window.LayoutHeader = LayoutHeader;