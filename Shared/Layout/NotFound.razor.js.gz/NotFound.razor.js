export class NotFound {
  
}

window.NotFound = NotFound;