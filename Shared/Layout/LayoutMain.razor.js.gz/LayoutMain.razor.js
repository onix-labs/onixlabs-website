export class LayoutMain {
  
}

window.LayoutMain = LayoutMain;