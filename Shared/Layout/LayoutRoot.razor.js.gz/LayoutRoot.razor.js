export class LayoutRoot {
  
}

window.LayoutRoot = LayoutRoot;