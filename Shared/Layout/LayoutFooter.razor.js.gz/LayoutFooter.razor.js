export class LayoutFooter {
  
}

window.LayoutFooter = LayoutFooter;