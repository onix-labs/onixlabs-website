export class Contributor {
  
}

window.Contributor = Contributor;