export class Biography {
  
}

window.Biography = Biography;