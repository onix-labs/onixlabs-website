export class Tech {
  
}

window.Tech = Tech;