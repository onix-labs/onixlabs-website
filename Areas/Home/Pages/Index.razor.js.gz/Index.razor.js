export class Index {
  
}

window.Index = Index;