export class Laura {
  
}

window.Laura = Laura;