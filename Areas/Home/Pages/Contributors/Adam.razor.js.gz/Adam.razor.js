export class Adam {
  
}

window.Adam = Adam;