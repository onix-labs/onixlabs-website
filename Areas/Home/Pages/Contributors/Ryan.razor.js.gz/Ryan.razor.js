export class Ryan {
  
}

window.Ryan = Ryan;