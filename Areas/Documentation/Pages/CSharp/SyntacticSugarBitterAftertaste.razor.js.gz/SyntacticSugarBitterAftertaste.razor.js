export class SyntacticSugarBitterAftertaste {
  
}

window.SyntacticSugarBitterAftertaste = SyntacticSugarBitterAftertaste;