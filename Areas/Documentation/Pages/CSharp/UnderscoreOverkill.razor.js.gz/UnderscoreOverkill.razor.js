export class UnderscoreOverkill {
  
}

window.UnderscoreOverkill = UnderscoreOverkill;