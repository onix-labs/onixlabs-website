export class IntroductionToAero {
  
}

window.IntroductionToAero = IntroductionToAero;