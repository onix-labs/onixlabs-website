export class RelationalDataAndPointers {
  
}

window.RelationalDataAndPointers = RelationalDataAndPointers;