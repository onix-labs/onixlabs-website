export class FlowDesignGuidelines2 {
  
}

window.FlowDesignGuidelines2 = FlowDesignGuidelines2;