export class FlowDesignGuidelines3 {
  
}

window.FlowDesignGuidelines3 = FlowDesignGuidelines3;