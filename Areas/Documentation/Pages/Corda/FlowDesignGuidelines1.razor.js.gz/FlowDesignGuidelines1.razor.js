export class FlowDesignGuidelines1 {
  
}

window.FlowDesignGuidelines1 = FlowDesignGuidelines1;