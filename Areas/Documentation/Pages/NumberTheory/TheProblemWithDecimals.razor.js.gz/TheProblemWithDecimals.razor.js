export class TheProblemWithDecimals {
  
}

window.TheProblemWithDecimals = TheProblemWithDecimals;