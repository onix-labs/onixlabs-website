export class MarkdownContent {
  
}

window.MarkdownContent = MarkdownContent;