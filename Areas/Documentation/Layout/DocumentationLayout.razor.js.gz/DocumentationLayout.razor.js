export class ArticlesLayout {
  
}

window.ArticlesLayout = ArticlesLayout;