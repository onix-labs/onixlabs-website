export class CordaIdfxLibrary {
  
}

window.CordaIdfxLibrary = CordaIdfxLibrary;