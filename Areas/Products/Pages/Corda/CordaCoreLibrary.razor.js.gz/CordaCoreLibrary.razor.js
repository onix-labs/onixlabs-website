export class CordaCoreLibrary {
  
}

window.CordaCoreLibrary = CordaCoreLibrary;