export class CordaBnmsLibrary {
  
}

window.CordaBnmsLibrary = CordaBnmsLibrary;