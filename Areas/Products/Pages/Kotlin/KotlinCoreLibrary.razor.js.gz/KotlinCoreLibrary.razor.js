export class KotlinCoreLibrary {
  
}

window.KotlinCoreLibrary = KotlinCoreLibrary;