export class KotlinProjectionLibrary {
  
}

window.KotlinProjectionLibrary = KotlinProjectionLibrary;