export class KotlinValidationLibrary {
  
}

window.KotlinValidationLibrary = KotlinValidationLibrary;