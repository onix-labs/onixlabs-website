export class AeroPlatform {
  
}

window.AeroPlatform = AeroPlatform;