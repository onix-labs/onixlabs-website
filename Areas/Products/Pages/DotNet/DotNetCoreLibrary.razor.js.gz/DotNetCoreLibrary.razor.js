export class DotNetCoreLibrary {
  
}

window.DotNetCoreLibrary = DotNetCoreLibrary;