export class DotNetNumericsLibrary {
  
}

window.DotNetNumericsLibrary = DotNetNumericsLibrary;