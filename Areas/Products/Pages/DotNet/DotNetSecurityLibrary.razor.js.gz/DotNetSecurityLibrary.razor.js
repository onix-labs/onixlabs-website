export class DotNetSecurityLibrary {
  
}

window.DotNetSecurityLibrary = DotNetSecurityLibrary;