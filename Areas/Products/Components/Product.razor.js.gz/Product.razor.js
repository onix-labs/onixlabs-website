export class Product {
  
}

window.Product = Product;