export class Summary {
  
}

window.Summary = Summary;