export class TokenGenerator {
  
}

window.TokenGenerator = TokenGenerator;