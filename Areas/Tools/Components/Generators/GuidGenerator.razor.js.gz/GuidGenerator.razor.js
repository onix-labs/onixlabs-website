export class GuidGenerator {
  
}

window.GuidGenerator = GuidGenerator;