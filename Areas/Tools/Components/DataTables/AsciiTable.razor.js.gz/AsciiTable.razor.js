export class AsciiTable {
  
}

window.AsciiTable = AsciiTable;