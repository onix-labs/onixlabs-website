export class HashGenerator {
  
}

window.HashGenerator = HashGenerator;