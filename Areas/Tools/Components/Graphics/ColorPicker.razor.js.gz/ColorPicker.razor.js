export class ColorPicker {
  
}

window.ColorPicker = ColorPicker;