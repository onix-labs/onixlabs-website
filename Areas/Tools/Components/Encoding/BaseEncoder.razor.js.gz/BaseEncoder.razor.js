export class BaseEncoder {
  
}

window.BaseEncoder = BaseEncoder;