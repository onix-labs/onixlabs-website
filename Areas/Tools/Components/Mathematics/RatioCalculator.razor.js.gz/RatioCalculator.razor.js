export class RatioCalculator {
  
}

window.RatioCalculator = RatioCalculator;