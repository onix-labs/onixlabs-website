export class ToolsLayout {
  
}

window.ToolsLayout = ToolsLayout;